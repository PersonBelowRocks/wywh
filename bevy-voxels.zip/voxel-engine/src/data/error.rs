#[derive(te::Error, Debug)]
#[error("TODO")]
pub struct TileDataConversionError;
